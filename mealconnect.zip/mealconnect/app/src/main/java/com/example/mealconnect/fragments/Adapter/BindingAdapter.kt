package com.example.mealconnect.fragments.Adapter

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide

class BindingAdapter {

    companion object{

        @BindingAdapter("android:convertlinktoimage")
        @JvmStatic
        fun convertLinkToImage(imageView: ImageView,imageurl:String){
            Glide.with(imageView.context)
                .load(imageurl)
                .centerCrop()
                .into(imageView)
        }

    }

}