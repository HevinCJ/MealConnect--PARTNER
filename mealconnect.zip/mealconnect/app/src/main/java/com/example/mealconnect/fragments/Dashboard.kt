package com.example.mealconnect.fragments

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.mealconnect.R
import com.example.mealconnect.databinding.FragmentDashboardBinding
import com.example.mealconnect.fragments.Adapter.MealAdapter
import com.example.mealconnect.viewmodel.MainViewModel


class dashboard : Fragment() {

    private var dashboard:FragmentDashboardBinding?=null
    private val binding get() = dashboard!!

    private val mainviewwmodel:MainViewModel by viewModels()
    private val adapter:MealAdapter by lazy { MealAdapter() }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        dashboard = FragmentDashboardBinding.inflate(layoutInflater,container,false)

        setUpRecyclerView()

        binding.actionbtntoadd.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_addmeal)
        }
        mainviewwmodel.getAllData.observe(viewLifecycleOwner){userdata->
            adapter.setdata(userdata)
        }





     return(binding.root)
    }

    private fun setUpRecyclerView() {
        binding.recyclerview.adapter=adapter
        binding.recyclerview.layoutManager=LinearLayoutManager(requireContext())
    }


}