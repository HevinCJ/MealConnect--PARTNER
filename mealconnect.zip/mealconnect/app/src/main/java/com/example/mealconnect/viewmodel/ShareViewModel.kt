package com.example.mealconnect.viewmodel

import android.app.Application
import android.text.TextUtils
import androidx.lifecycle.AndroidViewModel

class ShareViewModel(application: Application):AndroidViewModel(application) {


    fun UserDataValidation(mealname: String, number: String, amount: String, descp: String, image: String):Boolean{
        return if(TextUtils.isEmpty(mealname)||TextUtils.isEmpty(number)||TextUtils.isEmpty(amount)||TextUtils.isEmpty(descp)||TextUtils.isEmpty(image)){
            false
        }else{
            true
        }
    }
}