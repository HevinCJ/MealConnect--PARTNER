package com.example.mealconnect.fragments.add

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.graphics.drawable.toDrawable
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.example.mealconnect.R
import com.example.mealconnect.databinding.FragmentAddmealBinding
import com.example.mealconnect.utils.UserData
import com.example.mealconnect.viewmodel.ShareViewModel
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference


class addmeal : Fragment() {
    private var addfrag: FragmentAddmealBinding? = null
    private val binding get() = addfrag!!
    private lateinit var auth: FirebaseAuth
    private lateinit var databaseref: DatabaseReference
    private lateinit var storageref: StorageReference
    private lateinit var id: String

    private val sharedviewmodel: ShareViewModel by viewModels()
    private var imageuri: Uri? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        addfrag = FragmentAddmealBinding.inflate(layoutInflater, container, false)
        auth = FirebaseAuth.getInstance()
        databaseref = FirebaseDatabase.getInstance().getReference("Users")
        id = databaseref.push().key.toString()
        storageref = FirebaseStorage.getInstance().getReference("Images")



        binding.addmealbtn.setOnClickListener {
            insertDataIntoFirebase()
        }


        val pickimage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            binding.imageButton.setImageURI(uri)
            if (uri != null) {
                imageuri = uri
            }
        }

        binding.imageButton.setOnClickListener {
            pickimage.launch("image/*")
        }


        return binding.root
    }

    private fun insertDataIntoFirebase() {
        val mealname = binding.titletxt.editText?.text.toString()
        val number = binding.edttxtphoneno.editText?.text.toString()
        val amount = binding.edttxtamount.editText?.text.toString()
        val descp = binding.edttxtdescp.editText?.text.toString()

        imageuri?.let {
            storageref.child(id).putFile(it)
                .addOnSuccessListener { task ->
                    task.metadata?.reference?.downloadUrl
                        ?.addOnSuccessListener { url ->
                            val imageurl = url.toString()

                            if (sharedviewmodel.UserDataValidation(mealname, number, amount, descp, imageurl)) {
                                val user = UserData(id, mealname, imageurl, number, amount, descp)

                                databaseref.child(id).setValue(user).addOnCompleteListener {
                                    if (it.isSuccessful) {
                                        Toast.makeText(
                                            requireContext(),
                                            "Added $mealname",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        findNavController().navigate(R.id.action_addmeal_to_dashboard)
                                    } else {
                                        Toast.makeText(
                                            requireContext(),
                                            "Failed to add $mealname",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                            } else {
                                Toast.makeText(
                                    requireContext(),
                                    "Please Fill the Fields",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                        ?.addOnFailureListener { exception ->
                            Toast.makeText(
                                requireContext(),
                                "Failed to retrieve image URL. ${exception.message}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                }
                .addOnFailureListener { exception ->
                    Toast.makeText(
                        requireContext(),
                        "Failed to upload image. ${exception.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
        } ?: run {
            Toast.makeText(
                requireContext(),
                "Image is null. Please select an image.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }





}