package com.example.mealconnect.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import com.example.mealconnect.utils.UserData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainViewModel(application: Application):AndroidViewModel(application) {

    private var databaseref:DatabaseReference?=null
    private var auth:FirebaseAuth?=null
    private var id:String?=null
    var getAllData = MutableLiveData<List<UserData>>()

    init {
        databaseref=FirebaseDatabase.getInstance().getReference("Users")
        auth = FirebaseAuth.getInstance()
        id=databaseref?.push()?.key
        getAllDataFromFirebase()
    }

    fun getAllDataFromFirebase(){
        databaseref?.addValueEventListener(object:ValueEventListener{
            val userlist = mutableListOf<UserData?>()
            override fun onDataChange(snapshot: DataSnapshot) {
                for(data in snapshot.children){
                    val user = data.getValue(UserData::class.java)
                        userlist.add(user)
                }
                getAllData.value= userlist.filterNotNull()
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })
    }

}