package com.example.mealconnect.utils


data class UserData(
    val id:String,
    val mealname:String,
    val image:String,
    val phoneno:String,
    val amount:String,
    val descp:String

){
    constructor():this("","","","","","")
}
